#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SonyExRAW 本地提取工具

从本机已安装的 Sony Imaging Edge Desktop 中，把「Extended Hi-Res」
单帧超分模型解密、还原为通用 ONNX，并拆出逐张量权重（.npy）。

特点
  * 完全离线：只读本机已安装程序和它的模型缓存，不访问网络
  * 不依赖第三方包：AES 走 Windows CNG(bcrypt)，ONNX 解析为内置实现
  * 自动适配：密钥优先从本机 Viewer.exe 中现场恢复，失败才用内置值
  * 自带校验：解密后校验 base64/ONNX 结构，导出后给出逐张量 SHA-256

用法
  python sony_exraw_extract.py                  # 自动找 IEDT 与模型缓存
  python sony_exraw_extract.py --out D:\\out
  python sony_exraw_extract.py --models "C:\\ProgramData\\Sony\\Imaging Edge\\OnnxData"
  python sony_exraw_extract.py --iedt "C:\\Program Files\\Sony\\Imaging Edge"
"""

import argparse
import base64
import ctypes
import hashlib
import json
import os
import re
import struct
import sys

KNOWN_KEY = bytes.fromhex("7b7e151628aed2a6ab77158809cf4f2c")
ZERO_IV = b"\x00" * 16


# --------------------------------------------------------------------------
# AES-128-CBC
# --------------------------------------------------------------------------
class _BcryptAes:
    """Windows CNG (bcrypt.dll) AES-CBC 实现，纯 ctypes，无需安装依赖。"""

    BCRYPT_AES_ALGORITHM = "AES"
    BCRYPT_CHAINING_MODE = "ChainingMode"
    BCRYPT_CHAIN_MODE_CBC = "ChainingModeCBC"

    def __init__(self, key):
        if len(key) != 16:
            raise ValueError("AES-128 key must be 16 bytes")
        self._bcrypt = ctypes.WinDLL("bcrypt", use_last_error=True)
        self._alg = ctypes.c_void_p()
        self._key = ctypes.c_void_p()
        self._key_obj = ctypes.create_string_buffer(4096)
        self._open(key)

    def _check(self, status, what):
        if status != 0:
            raise OSError("bcrypt %s failed: 0x%08x" % (what, status & 0xFFFFFFFF))

    def _open(self, key):
        b = self._bcrypt
        self._check(b.BCryptOpenAlgorithmProvider(
            ctypes.byref(self._alg), self.BCRYPT_AES_ALGORITHM, None, 0), "open")
        mode = self.BCRYPT_CHAIN_MODE_CBC.encode("utf-16-le")
        self._check(b.BCryptSetProperty(
            self._alg, self.BCRYPT_CHAINING_MODE,
            ctypes.c_char_p(mode), len(mode), 0), "set-mode")
        self._check(b.BCryptGenerateSymmetricKey(
            self._alg, ctypes.byref(self._key), self._key_obj,
            len(self._key_obj), ctypes.c_char_p(key), len(key), 0), "gen-key")

    def decrypt(self, data):
        """CBC 解密；不处理填充，返回等长明文。"""
        b = self._bcrypt
        out = ctypes.create_string_buffer(len(data))
        iv = ctypes.create_string_buffer(ZERO_IV, 16)
        done = ctypes.c_ulong(0)
        self._check(b.BCryptDecrypt(
            self._key, ctypes.c_char_p(data), len(data), None,
            iv, 16, out, len(data), ctypes.byref(done), 0), "decrypt")
        return out.raw[:done.value]

    def close(self):
        try:
            if self._key:
                self._bcrypt.BCryptDestroyKey(self._key)
            if self._alg:
                self._bcrypt.BCryptCloseAlgorithmProvider(self._alg, 0)
        except Exception:
            pass

    def __del__(self):
        self.close()


def _soft_aes_decrypt(key, data):
    """后备：cryptography / pycryptodome（若已安装）。"""
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        d = Cipher(algorithms.AES(key), modes.CBC(ZERO_IV)).decryptor()
        return d.update(data) + d.finalize()
    except ImportError:
        pass
    try:
        from Crypto.Cipher import AES
        return AES.new(key, AES.MODE_CBC, ZERO_IV).decrypt(data)
    except ImportError:
        raise RuntimeError(
            "无法初始化 AES：需要 Windows(bcrypt) 或 cryptography / pycryptodome")


class AesCbc:
    def __init__(self, key):
        self._impl = None
        if os.name == "nt":
            try:
                self._impl = _BcryptAes(key)
            except Exception:
                self._impl = None
        if self._impl is None:
            self._impl = ("soft", key)

    def decrypt(self, data):
        if isinstance(self._impl, tuple):
            return _soft_aes_decrypt(self._impl[1], data)
        return self._impl.decrypt(data)

    def decrypt_pkcs7(self, data):
        if len(data) % 16:
            raise ValueError("ciphertext length not a multiple of 16")
        plain = self.decrypt(data)
        if not plain:
            return plain
        pad = plain[-1]
        if not 1 <= pad <= 16 or plain[-pad:] != bytes([pad]) * pad:
            raise ValueError("bad PKCS#7 padding (wrong key?)")
        return plain[:-pad]

    def close(self):
        impl = self._impl
        if isinstance(impl, tuple):
            return
        try:
            impl.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


# --------------------------------------------------------------------------
# 从本机 Viewer.exe 现场恢复密钥
# --------------------------------------------------------------------------
def _text_section(path):
    with open(path, "rb") as f:
        data = f.read()
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    nsec = struct.unpack_from("<H", data, e_lfanew + 6)[0]
    optsz = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    base = e_lfanew + 24 + optsz
    for i in range(nsec):
        off = base + i * 40
        name = data[off:off + 8].rstrip(b"\0")
        vsize, vaddr, rsize, raw = struct.unpack_from("<IIII", data, off + 8)
        if name == b".text":
            return data[raw:raw + rsize]
    return b""


def _imm32_movs(text):
    """收集 `C7 /0 ... imm32`（mov dword ptr [...], imm32）的位置与立即数。"""
    out = []
    n = len(text)
    i = 0
    while i < n - 7:
        if text[i] == 0xC7:
            modrm = text[i + 1]
            mod = modrm >> 6
            rm = modrm & 7
            p = i + 2
            if rm == 4:          # SIB
                p += 1
            if mod == 0:
                if rm == 5:      # disp32（绝对地址）
                    p += 4
            elif mod == 1:
                p += 1
            elif mod == 2:
                p += 4
            else:
                i += 1
                continue
            if p + 4 <= n:
                out.append((i, struct.unpack_from("<I", text, p)[0]))
                i = p + 4
                continue
        i += 1
    return out


def recover_keys(viewer_path):
    """返回候选 AES 密钥列表（内置值 + 从本机二进制里恢复的候选）。"""
    keys = [KNOWN_KEY]
    if not viewer_path or not os.path.exists(viewer_path):
        return keys
    try:
        text = _text_section(viewer_path)
        movs = _imm32_movs(text)
        for i in range(len(movs) - 3):
            grp = movs[i:i + 4]
            pos = [g[0] for g in grp]
            if pos[-1] - pos[0] > 48:
                continue
            if any(pos[k + 1] - pos[k] > 32 for k in range(3)):
                continue
            cand = b"".join(struct.pack("<I", g[1]) for g in grp)
            if cand not in keys:
                keys.append(cand)
    except Exception:
        pass
    return keys


# --------------------------------------------------------------------------
# 解密 + 识别
# --------------------------------------------------------------------------
_B64_RE = re.compile(rb"^[A-Za-z0-9+/=\r\n]+$")


def looks_like_encrypted_onnx(plain):
    """明文应是 base64 文本，解码后以 protobuf tag 0x08 开头。"""
    if len(plain) < 8 or not _B64_RE.match(plain[:4096]):
        return False
    head = plain[:4096]
    head = head[:len(head) - (len(head) % 4)]
    try:
        raw = base64.b64decode(head, validate=True)
    except Exception:
        return False
    return raw[:1] == b"\x08"


def try_decrypt_file(path, keys, probe=65536):
    """用候选密钥试解文件；返回 (key, plaintext_bytes) 或 (None, None)。"""
    with open(path, "rb") as f:
        head = f.read(probe - probe % 16)
    for key in keys:
        try:
            with AesCbc(key) as aes:
                plain = (aes.decrypt_pkcs7(head) if len(head) < probe
                         else aes.decrypt(head))
        except Exception:
            continue
        if looks_like_encrypted_onnx(plain):
            with open(path, "rb") as f:
                blob = f.read()
            with AesCbc(key) as aes:
                return key, aes.decrypt_pkcs7(blob)
    return None, None


# --------------------------------------------------------------------------
# 内置 ONNX 解析（无 onnx / protobuf 依赖）
# --------------------------------------------------------------------------
class _R:
    def __init__(self, b, p=0, e=None):
        self.b, self.p, self.e = b, p, (len(b) if e is None else e)

    def eof(self):
        return self.p >= self.e

    def varint(self):
        sh = v = 0
        while True:
            c = self.b[self.p]
            self.p += 1
            v |= (c & 0x7F) << sh
            if not c & 0x80:
                return v
            sh += 7

    def key(self):
        k = self.varint()
        return k >> 3, k & 7

    def bytes(self):
        n = self.varint()
        s = self.b[self.p:self.p + n]
        self.p += n
        return s

    def skip(self, wt):
        if wt == 0:
            self.varint()
        elif wt == 1:
            self.p += 8
        elif wt == 2:
            self.bytes()
        elif wt == 5:
            self.p += 4
        else:
            raise ValueError("wire %d" % wt)


_DT = {1: ("float32", 4, "<f4"), 2: ("uint8", 1, "u1"), 3: ("int8", 1, "i1"),
       4: ("uint16", 2, "<u2"), 5: ("int16", 2, "<i2"), 6: ("int32", 4, "<i4"),
       7: ("int64", 8, "<i8"), 9: ("bool", 1, "?"), 10: ("float16", 2, "<f2"),
       11: ("float64", 8, "<f8"), 12: ("uint32", 4, "<u4"), 13: ("uint64", 8, "<u8")}


class _Tensor:
    def __init__(self):
        self.name = ""
        self.dims = []
        self.dtype = 1
        self.raw = None
        self.float_data = None
        self.int32_data = None
        self.int64_data = None


def _parse_tensor(buf):
    t = _Tensor()
    r = _R(buf)
    while not r.eof():
        f, wt = r.key()
        if f == 1:
            if wt == 2:
                rr = _R(r.bytes())
                while not rr.eof():
                    t.dims.append(rr.varint())
            else:
                t.dims.append(r.varint())
        elif f == 2:
            t.dtype = r.varint()
        elif f == 4:
            d = r.bytes()
            t.float_data = list(struct.unpack("<%df" % (len(d) // 4), d))
        elif f == 5:
            d = r.bytes()
            t.int32_data = list(struct.unpack("<%di" % (len(d) // 4), d))
        elif f == 8:
            t.name = r.bytes().decode("utf-8", "replace")
        elif f == 9:
            t.raw = r.bytes()
        elif f == 10:
            d = r.bytes()
            t.int64_data = list(struct.unpack("<%dq" % (len(d) // 8), d))
        else:
            r.skip(wt)
    return t


def parse_onnx(buf):
    r = _R(buf)
    meta = {}
    graph = None
    while not r.eof():
        f, wt = r.key()
        if f == 1:
            meta["ir_version"] = r.varint()
        elif f == 2:
            meta["producer_name"] = r.bytes().decode("utf-8", "replace")
        elif f == 3:
            meta["producer_version"] = r.bytes().decode("utf-8", "replace")
        elif f == 4:
            meta["domain"] = r.bytes().decode("utf-8", "replace")
        elif f == 7:
            g = r.bytes()
            gr = _R(g)
            inits, nodes, gname = [], 0, ""
            ops = {}
            while not gr.eof():
                gf, gw = gr.key()
                if gf == 1:
                    node = _R(gr.bytes())
                    nd = _parse_node(node)
                    nodes += 1
                    ops[nd] = ops.get(nd, 0) + 1
                elif gf == 2:
                    gname = gr.bytes().decode("utf-8", "replace")
                elif gf == 5:
                    inits.append(_parse_tensor(gr.bytes()))
                else:
                    gr.skip(gw)
            graph = {"name": gname, "nodes": nodes, "ops": ops, "inits": inits}
        else:
            r.skip(wt)
    return meta, graph


def _parse_node(r):
    op = ""
    while not r.eof():
        f, wt = r.key()
        if f == 4:
            op = r.bytes().decode("utf-8", "replace")
        else:
            r.skip(wt)
    return op


def tensor_array(t, np):
    if t.raw is not None:
        info = _DT.get(t.dtype)
        if not info:
            raise ValueError("unsupported dtype %d" % t.dtype)
        if info[0] == "float16":
            return np.frombuffer(t.raw, dtype="<f2").astype(np.float32)
        return np.frombuffer(t.raw, dtype=info[2]).copy()
    if t.float_data is not None:
        return np.asarray(t.float_data, dtype=np.float32)
    if t.int64_data is not None:
        return np.asarray(t.int64_data, dtype=np.int64)
    if t.int32_data is not None:
        return np.asarray(t.int32_data, dtype=np.int32)
    return np.zeros(t.dims, dtype=np.float32)


# --------------------------------------------------------------------------
# 定位 IEDT / 模型缓存
# --------------------------------------------------------------------------
def find_iedt(explicit=None):
    cands = []
    if explicit:
        cands.append(explicit)
    for env in ("ProgramFiles", "ProgramFiles(x86)"):
        root = os.environ.get(env)
        if root:
            cands += [os.path.join(root, "Sony", "Imaging Edge"),
                      os.path.join(root, "Sony", "Imaging Edge Desktop")]
    try:
        import winreg
        for hive, path in ((winreg.HKEY_LOCAL_MACHINE,
                            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
                           (winreg.HKEY_LOCAL_MACHINE,
                            r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall")):
            with winreg.OpenKey(hive, path) as k:
                for i in range(winreg.QueryInfoKey(k)[0]):
                    try:
                        sub = winreg.EnumKey(k, i)
                        with winreg.OpenKey(k, sub) as sk:
                            name = winreg.QueryValueEx(sk, "DisplayName")[0]
                            if "Imaging Edge" in name:
                                loc = winreg.QueryValueEx(sk, "InstallLocation")[0]
                                if loc:
                                    cands.append(loc)
                    except OSError:
                        continue
    except Exception:
        pass
    for c in cands:
        p = os.path.join(c, "Viewer.exe")
        if os.path.exists(p):
            return c
    # 浅层搜索
    for env in ("ProgramFiles", "ProgramFiles(x86)"):
        root = os.environ.get(env)
        if not root or not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(os.path.join(root, "Sony")):
            if "Viewer.exe" in filenames:
                return dirpath
            if dirpath.count(os.sep) - root.count(os.sep) > 4:
                dirnames[:] = []
    return None


def find_models(explicit=None):
    dirs = []
    if explicit:
        dirs.append(explicit)
    pd = os.environ.get("ProgramData", r"C:\ProgramData")
    la = os.environ.get("LOCALAPPDATA", "")
    dirs += [
        os.path.join(pd, "Sony", "Imaging Edge", "OnnxData"),
        os.path.join(la, "Sony Corporation", "Imaging Edge Desktop", "OnnxData") if la else "",
        os.path.join(la, "Sony", "Imaging Edge", "OnnxData") if la else "",
    ]
    out = []
    for d in dirs:
        if not d or not os.path.isdir(d):
            continue
        for name in sorted(os.listdir(d)):
            p = os.path.join(d, name)
            if os.path.isfile(p) and os.path.getsize(p) > 1 << 20:
                out.append(p)
    return out


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------
def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def main():
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="SonyExRAW 本地权重提取")
    ap.add_argument("--iedt", help="Imaging Edge 安装目录（含 Viewer.exe）")
    ap.add_argument("--models", help="模型缓存目录（含 8 位十六进制 .0001 文件）")
    ap.add_argument("--out", default=os.path.join(os.getcwd(), "SonyExRAW输出"))
    ap.add_argument("--key", help="手动指定 16 字节 AES 密钥（hex，可选）")
    ap.add_argument("--no-weights", action="store_true", help="只输出 ONNX，不拆 .npy")
    ap.add_argument("--download", action="store_true",
                    help="本地没有模型时，从官方接口下载（默认关闭）")
    a = ap.parse_args()

    print("=" * 64)
    print("SonyExRAW 本地提取")
    print("=" * 64)

    iedt = find_iedt(a.iedt)
    viewer = os.path.join(iedt, "Viewer.exe") if iedt else None
    print("IEDT     :", iedt or "未找到（可用 --iedt 指定）")

    models = find_models(a.models)
    print("模型缓存 :", a.models or os.path.join(
        os.environ.get("ProgramData", r"C:\ProgramData"), "Sony", "Imaging Edge", "OnnxData"))
    print("待处理   : %d 个文件" % len(models))
    if not models:
        print("\n没有找到模型文件。")
        print("请先在 IEDT 里执行一次「Extended RAW Processing → Extended Hi-Res」")
        print("让官方程序把模型下载到 OnnxData，然后重新运行本工具。")
        if a.download:
            print("（--download 模式未实现：本工具定位为离线提取）")
        return 2

    keys = [bytes.fromhex(a.key)] if a.key else recover_keys(viewer)
    print("候选密钥 : %d 个（首个为内置值，其余从本机二进制恢复）" % len(keys))

    os.makedirs(a.out, exist_ok=True)
    np = None
    if not a.no_weights:
        try:
            import numpy as np
        except ImportError:
            print("提示：未安装 numpy，将只输出 ONNX 与清单（不拆 .npy）")

    rows = []
    ok = 0
    for p in models:
        name = os.path.splitext(os.path.basename(p))[0]
        print("\n[%s] %.1f MiB" % (os.path.basename(p), os.path.getsize(p) / 1048576))
        key, plain = try_decrypt_file(p, keys)
        if key is None:
            print("  跳过：不是可识别的模型文件（或密钥未知）")
            continue
        print("  密钥   :", key.hex(), "(内置)" if key == KNOWN_KEY else "(本地恢复)")
        try:
            onnx = base64.b64decode(plain, validate=True)
        except Exception as e:
            print("  跳过：base64 解码失败", e)
            continue
        if onnx[:1] != b"\x08":
            print("  跳过：不是 ONNX")
            continue
        meta, graph = parse_onnx(onnx)
        onnx_path = os.path.join(a.out, name + ".onnx")
        with open(onnx_path, "wb") as f:
            f.write(onnx)
        print("  ONNX   : %s  %d B  sha256=%s" %
              (os.path.basename(onnx_path), len(onnx), hashlib.sha256(onnx).hexdigest()))
        print("  图     : %s  节点=%d  张量=%d" %
              (graph["name"], graph["nodes"], len(graph["inits"])))
        ok += 1

        if np is None:
            continue
        wdir = os.path.join(a.out, "weights")
        os.makedirs(wdir, exist_ok=True)
        for t in graph["inits"]:
            arr = tensor_array(t, np)
            fn = re.sub(r"[^0-9A-Za-z_.-]", "_", t.name.replace("/", ".").lstrip("@")) + ".npy"
            np.save(os.path.join(wdir, fn), arr)
            rows.append({"model": name, "tensor": t.name, "file": "weights/" + fn,
                         "shape": [int(x) for x in t.dims],
                         "dtype": _DT.get(t.dtype, ("?",))[0],
                         "bytes": int(arr.nbytes),
                         "sha256": hashlib.sha256(arr.tobytes()).hexdigest()})
        print("  权重   : %d 个张量已拆分" % len(graph["inits"]))

    if rows:
        with open(os.path.join(a.out, "weights_index.csv"), "w", encoding="utf-8") as f:
            f.write("model,tensor,file,shape,dtype,bytes,sha256\n")
            for r in rows:
                f.write("%s,%s,%s,%s,%s,%d,%s\n" % (
                    r["model"], r["tensor"], r["file"],
                    "x".join(map(str, r["shape"])), r["dtype"], r["bytes"], r["sha256"]))
        with open(os.path.join(a.out, "weights_index.json"), "w", encoding="utf-8") as f:
            json.dump(rows, f, indent=1, ensure_ascii=False)
        print("\n清单:", os.path.join(a.out, "weights_index.csv"))

    print("\n完成：%d 个模型已导出到 %s" % (ok, a.out))
    return 0 if ok else 3


if __name__ == "__main__":
    sys.exit(main())
