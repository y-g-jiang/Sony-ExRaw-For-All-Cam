@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo.
    echo  Python not found.
    echo  Please install Python 3.8+ and enable "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

py -3 "%~dp0sony_exraw_extract.py" %*

echo.
pause
